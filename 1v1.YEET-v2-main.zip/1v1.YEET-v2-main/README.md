# 1v1.YEET-v2
An improved Cheat Engine hack for the game 1v1.lol 

### Current Status: Working (last checked April 8th, 2021)

### Note: This has only been tested on Windows 10 64-bit but may work on other versions of Windows. Support for other operating systems is not planned. This has also only been tested on Firefox, Brave, and Chrome. Also, having Badlion Client installed may cause Cheat Engine to not work. 

## INSTRUCTIONS: 

1.) Download Cheat Engine from https://cheatengine.org/ 

If you already have cheat engine, update to version 7.2 

*Cheat Engine tends to bundle useless bundleware, so make sure you read the installation window and make sure you are installing only Cheat Engine and not anything else if you don't want bundleware.*

2.) (Optional) Download Firefox from https://www.mozilla.org/en-US/firefox/new/ 

3.) Download and run "1v1.YEET_v2.CETRAINER" 

4.) Open a SINGLE tab to [1v1.lol](https://1v1.lol) in your browser. Make sure that 1v1.lol is only opened in one tab. 

5.) If you are using Firefox, you can use the auto attachment mode. Simply press "attach process" to attach. 

*If this doesn't work, try using manual mode.* 

6.) Enable the features and destroy your friends at the game! 

### Manual Mode Instructions: 

Someone made a video on how to do manual mode. It's at https://www.youtube.com/watch?v=2nDErISetRc 

**If you are using manual mode, you need to make sure that 1v1.lol is the only tab open!** 

1.) If you are using a browser other than Firefox or prefer manual mode, go to Task Manager and press the "details" tab. 

*If you aren't using Firefox, you need to be using Chrome or a Chromium-based browser such as Brave for compatibility mode to work.* 

![Details Tab](https://cdn.discordapp.com/attachments/693548483130556610/748647199398952990/detailstab.PNG)

2.) Scroll down to the firefox processes and look at the process with the most RAM being used. 

![RAM Usage](https://cdn.discordapp.com/attachments/693548483130556610/748647870269358120/ramusage.PNG)

3.) Look to the left and look at the PID. 

![PID Task Manager](https://cdn.discordapp.com/attachments/693548483130556610/748647871355813939/pidtaskmgr.PNG)

4.) Set the attachment mode to "Manual" and type the PID into the "PID" box. 

![PID Trainer](https://cdn.discordapp.com/attachments/768685505406697482/808161753463521280/cheatengine-x86_64-SSE4-AVX2_RsMzTnRNyM.png)

5.) Press "attach process." 

6.) Enable the features and destroy your friends at the game! 

### IMPORTANT: Please don't use this in competitive/ranked matches(the ones where you can gain/lose trophies) unless you are playing against your friends. 

## If this doesn't work, you may try the following: 

- If you were using a different browser, try using compatibility mode with Brave. If that doesn't work just use Firefox. 

- Try a different computer if you can 

- If you have Badlion Client installed, you may need to disable its anticheat or just uninstall it completely, as it stops cheat engine from running at all, even if the client isn't actually running (for some reason). 

- Make sure you are on the latest version of Cheat Engine 

- Reinstall Cheat Engine 
